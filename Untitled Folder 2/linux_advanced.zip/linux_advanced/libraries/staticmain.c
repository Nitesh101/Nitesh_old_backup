#include<stdio.h>
#include"addheader.h"
int main()
{
	int a=5;
	int b=6;
	add(a,b);
	return 0;
}
