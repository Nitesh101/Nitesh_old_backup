#include<stdio.h>
#include"subheader.h"
int main()
{
	int a=9;
	int b=4;
	sub(a,b);
	return 0;
}
