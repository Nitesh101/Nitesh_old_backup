int sub1(int a,int b)
{	
	int sub;
	sub=a-b;
	return sub;
}
