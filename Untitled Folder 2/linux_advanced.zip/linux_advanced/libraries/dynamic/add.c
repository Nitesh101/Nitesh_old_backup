int sum1(int a,int b)
{
	int sum;
	sum=a+b;
	return sum;
}
