int sum1(int,int);
int sub1(int,int);

