#include<stdio.h>
void sub1(int a,int b)
{
	int res;
	res = a-b;
	printf("result is %d\n",res);
}

