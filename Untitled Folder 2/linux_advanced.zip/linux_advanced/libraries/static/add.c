#include<stdio.h>
void add(int a, int b)
{
	int res;
	res=a+b;
	printf("result is %d\n :",res);
}
