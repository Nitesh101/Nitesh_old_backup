void sub(int a, int b)
