#include<stdio.h>
#include "dynamic/header.h"
int main()
{
	int a=3,b=4,c,d;
	c=sum1(a,b);
	d=sub1(a,b);
	printf("the values of add is %d\n",c);
	printf("the values of sub is %d\n",d);
	return;
}
