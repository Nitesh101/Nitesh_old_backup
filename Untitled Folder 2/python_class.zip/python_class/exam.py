#!/usr/bin/python
list = [1,3,5,6,-5,-2,10,-1,4,-2]
list1=[]
for i in list:
	if i >= 0:
		list1.append(i)
for i in list:
	if i <0:
		list1.append(i)
print list1
