#!/usr/bin/python
fo = open('foo.txt',"r")
print "Name of the file: ", foo.name
for index in range(6):
	line = fo.next()
	#line = fo.readlines(15);
	print" Line No %d - %s"%(index, line)
fo.close()
