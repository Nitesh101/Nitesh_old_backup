#!/usr/bin/python
class JustCounter :
	__secretCount = 0
	def count(self):
		self.__secretCount += 1
		#print self.__secretCount
counter = JustCounter()
counter.count()
counter.count()
print counter.__JustCounter__secretCount
