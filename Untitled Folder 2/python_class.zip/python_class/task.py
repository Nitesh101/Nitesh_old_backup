#!/usr/bin/python
#a = [1,3,6,8,9,10]
#print len(a)
"""
list1 = [1,2,4,5,6,7,8,9]
def binear_search(list1,seek):
	low = 0
	high = len(list1)-1
	while (low<=high):
		mid=low+(high-low+1)//2
		if(list1[mid]==seek):
			return mid
		elif(list1[mid]>seek):
			high=mid-1
		else:
			low=mid+1
	return None

print binear_search(list1,10)

dec = 344
print("this decimal value of",dec,"is:")
print(bin(dec),"in binary.")
print(oct(dec),"in octal.")
print(hex(dec),"in hexadecimal.")

dec = 344
print("this is decimal value",dec,"is:")
print(bin(dec),"in binary.")
print(oct(dec),"in octal.")
print(hex(dec),"in hexadecimal.")

def convertToBinary(n):
	"function to print binary number"
	if n > 1:
	       convertToBinary(n//2)
	print(n%2)
dec = 34
convertToBinary(dec)

def convertToBinary(n):
	"function to print binary number"
	if n > 1 :
		convertToBinary(n//2)
	print(n%2)
dec = 40
convertToBinary(dec)


x = 1
eval('x+1')
d = {'a':1,'b':2,'c':3}
c = d.items()
print c
import sys

print 'Number of aruments:', len(sys.argv),'arguments.'
print 'Argument List:', str(sys.argv)

import sys,getopt
def main(argv):
	inputfile = ''
	outputfile = ''
	try: 
	   opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
        except getopt.GetoptError:
	     print 'test.py -i <inputfile> -o <outputfile?'
	     sys.exit(2)
        for opt, arg in opts:
	     if opt == '-h':
		print 'test.py -i <inputfile> -o <outputfile>'
             sys.exit()
            elif opt in ("-i","--ifile"):
		print 


Number = int(input("\n please enter the range number"))
i = 0
First_value = 0
second_value = 1
while(i<Number):
	if(i<=1):
		next = i
	else:
		next = First_value + second_value
		First_value = second_value
		second_value = next
	print(next)
	i=i+1"
val1 = input("please enter the first number: ")
val2 = input("please enter the last number: ")
i=0
if(val1>3):
	prime_list=[]
if(val1<=3):
	prime_list=[2,3]
	val1=4
for count in range(val1,val2):
	i = 0
	for conut1 in range(2,count-1):
	#	print count1
		qout=count%count+1
		if(qout == 0):
			i=i+1
			break
		#	continue
		else:
			pass
	if(i==0):
		prime_list.append(count)
		continue
print prime_list

val1 = input("please enter a first number: ")
val2 = input("please enter a last number: ")
i=0
if (val1>1):
	prime_list=[]
if(val1<=1):	
	prime_list=[2,3]
	val1=4
for count in range(val1,val2):
	i=0
	for count1 in range(2,count-1):
		qout=count%count+1
                if(qout==0):
			i = i+1
		        break
		else:
			pass

	if(i==0):
		prime_list.append(count)
		continue
print prime_list

num = input("please enter a number: ")
if num > 1:
	for i in range(2,num):
		if(num%i)==0:
			print (num,"is not a prime")
			break
	else:
		print(num,"is a prime number")


data=input("please enter a list: ")
seek=input("please enter a number which is need to search: ")
length=len(data)
for index in range(length):
	if(seek==data[index]):
		print "number is present\nindex of the number is", index
		break;
else:
	print seek,"is not present in the list"
str1=input("enter a string: ")
sub_str=input("enter the sub string: ")
if (sub_str in str1):
	print sub_str ,"is a substring of",str1
elif (sub_str not in str1):
	print sub_str,"is not a substring",str1

init_val=input("please enter initial value")
final_val=input("please enter final value")
inc_val=input("please enter inc/dec value")
for val in range(init_val,final_val,inc_val):
	print val

"""
def print_factors(x):
	print ("The factors of",x,"are")
	for i in range(1,x+1)
		if x%i == 0:
			print(i)
num = input("please enter a number")
print_factors(num)

















