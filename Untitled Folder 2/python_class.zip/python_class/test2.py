#!/usr/bin/python
test = ["one.py","two.py","three.txt","four.cvs","five.txt","six.exl"]
a=[]
b=[]
c=[]
for i in test:
	if i.endswith("py"):
		a.append(i)
	if i.endswith("txt"):
		b.append(i)
print(a)
print(b)
