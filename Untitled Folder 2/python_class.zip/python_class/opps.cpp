#include<istream>
using namespace std;
class sample1{
	int v1;
	public:
		int v2;
	protected:
		int v3;
};

int main()
{
	class sample1 s1;
	s1.v1=20;
	count<<s1.v1;
}
