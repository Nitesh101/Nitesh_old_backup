#!/usr/bin/python
fo = open("input.txt","w")
fo.write("This is first line\n")
fo.write("this is second line\n")
fo.close()

