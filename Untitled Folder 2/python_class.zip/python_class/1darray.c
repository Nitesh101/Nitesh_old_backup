/*
#include<stdio.h>
int main(void)
{
	int i,j,temp,arr[10]={1,2,3,4,5,6,7,8,9,10};
	for (i=0,j=9;i<j;i++,j--)
	{
		temp = arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
	printf("After revresing : ");
		for(i=0;i<10;i++)
			printf("%d",arr[i]);
		printf("\n");
		return 0;
	} 
	*/
/*

	#include<stdio.h>
	int main(void)
	{
		int i,v;
		printf("enter a decimal value: ");
		scanf("%d",&v);
		for(i=7;i>=0;i--)
		{
			printf("%d",(v>>i)&1);
	}
	printf("\n");
	return
*/

#include<stdio.h>
void check(int num);
int main(void)
{
	int arr[10],i;
	printf("Enter the array elements : ");
	for(i=0;i<1;i++)
	{
		scanf("%d",&arr[i]);
		check(arr[i]);
	}
	return 0;
}
void check(int num)
{
	if(num%2==0)
		printf("%d is even\n",num);
	else
		printf("%d is odd\n",num);
}















