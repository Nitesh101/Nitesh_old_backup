#!/usr/bin/python
val = int(input("please enter a values: "))
mylist = []
for i in val:
	if val > 0:
		mylist.append(i)
print list(mylist)
print tuple(mylist)
print dict(list(mylist))
