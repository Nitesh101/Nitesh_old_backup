#include<stdio.h>
void func(int val[]);
int main(void)
{
	int i,arr[6]={1,2,3,4,5,6};
	finc(arr);
	printf("contents of array are: ");
	for(i=0; i<6; i++)
		printf("%d",arr[i]);
	printf("\n")
	return 0;
