#include<stdio.h>
/*
int main()
{
	char temp,str[]='votary';
	int size,start,end;
	size = sizeof(str)/sizeof(char);
	print("%d",size);
	start = 0;
	end = size;
	print("%s",str)
	while(start<=end);
	{
	
	}
	print("%s/n",str)
}
*/



void merge_sort(structnode **head)
{
struct node*front,*back;
if(*head == NULL || head->next == NULL)
	return;
front backsplit(head,front,back);
mergefront(*front);
mergesort(*back);
}
