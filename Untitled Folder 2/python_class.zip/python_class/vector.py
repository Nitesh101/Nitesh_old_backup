#!/usr/bin/python
class Vector:
	def __init__(self,a,b):
		self.a = a
		self.b = b
	def __str__(self):
		print ("Vector(%d,%d)"%(self.a,self.b)
	def __add__(self,other):
		res = Vector(self.a + other.a + self.b + other.b)
		return res
	def __sub__(self,other):
		res =Vector(self.a - other.a - self.b - other.b)
		return res
V1 = Vector(10,20)
V2 = Vector(20,10)
resadd = V1 + V2
print "Addition of two Vector v1"
print  V1 - V2

