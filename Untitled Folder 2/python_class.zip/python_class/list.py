#!/usr/bin/python
#str = '123456'
#letter = ['s','p','a','m']
#word = str.join(letter)
#print word
tup = [10,20,30,40]
print tup[3:-1:-1]
