#!/usr/bin/python
"""
val = input("please enter a decimal number : ")
ops = input("please eneter a position: ")
set1 = val |(1<<ops)
print bin(set1)
clear = val&(~1<<ops)
print bin(clear)
toggle = val ^(1<<ops)
print bin(toggle)
"""
str = "this is string example....wow!!!";
print str.swapcase();
str = "THIS IS STRING EXAMPLE....WOW!!!";
print str.swapcase();

str = "this is string example....wow!!!";
print str.title();


