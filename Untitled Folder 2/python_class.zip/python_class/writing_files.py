#!/usr/bin/python
outputfile = open("sample.txt","w")
outputfile.write("write something code")
outputfile.close()
					
