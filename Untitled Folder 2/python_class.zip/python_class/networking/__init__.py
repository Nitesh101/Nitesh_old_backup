#!/usr/bin/python
from fibanocii import recr_fibo
from prime import prime_number
