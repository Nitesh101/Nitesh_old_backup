#!/usr/bin/python
def recr_fibo(n):
	a,b=0,1
	c=0
	for i in range(n):
		print a
		#a,b=b,a+b	
		c=a+b
		a=b
		b=c	
