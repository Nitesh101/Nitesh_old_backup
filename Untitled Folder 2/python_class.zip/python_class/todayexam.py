"""
list1 = input("please enter a list: ")
tupel = input("please enter a tuple: ")
result = [val*val for val in list1]
result2 = [val*val for val in tupel]
print result
print tuple(result2)
result3 = set([val*val for val in list1])
print result3

list2 = input("please enter a list: ")
start ,stop,step = 0,10,1
if isinstance(list2,int):
	start = 0
	step = 1
	stop = list2
elif len(list2) == 2:
	start = list2[0]
	stop = list2[1]	
elif len(list2) == 3:
	start = list2[0]
	stop = list2[1]
	step = list2[2]
else:
	start = 0
	step = 1
	stop = 10
if(start<stop):	
	result = [val for val in range(start,stop,step) if val%2 == 0]
print result
temp = [val for val in range(10) for val2 in range(5)]
print temp

"""
list4 = input("please enter a 3 numbers: ")
result = lambda v1,v2,v3:v1+v2+v3
print result(list4[0],list4[1],list4[2])
