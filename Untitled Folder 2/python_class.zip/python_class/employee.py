#!/usr/bin/python
class Employee:
	'comman base class for all employee'
	empCount = 0
	
	def __init__(self,name,Salary):
		self.name=name
		self.Salary=Salary
		Employee.empCount +=1
	def displayCount(self):
		print "total Employee %d"%Employee.empCount
	def displayEmployee(self):
		print "Name:",self.name
		print "Salary:",self.Salary


emp1=Employee('nitesh',10000)
emp2=Employee('sandeep',2000)
emp1.displayEmployee()
emp2.displayEmployee()
emp1.displayCount()



