#!/usr/bin/python

import sys,getopt
def main(argv):
	sum1=0
	inputfile=""
	outputfile=""
	try:
		opts,argv=getopt.getopt(argv,"hi:o:",["inputfile=","outputfile="])
	except getopt.GetoptError:
		print("getopt.test.py -i<inputfile> -o<outputfile>")
		sys.exit(2)
	for opt,args in opts:
		if  opts == "-h":
			print ("getopts.test.py -i<inputfile> -o<outputfile>")
			sys.exit()
		elif opt in("-i","__inputfile"):
			inputfile=args
		elif opt in("-o","__outputfile"):
			outputfile=args
	print("inputfile is",inputfile)
	print("ouputfile is",outputfile)
	fo = open(inputfile,"w")
	fo.write("5\n")
	fo.write("2\n")
	fo.write("2\n")
	fo.close()
	fo = open(inputfile,"r")
	lines=fo.readlines()
	for line in lines:
		sum1+=int(line)
	fo.close()
	fo = open(outputfile,"w")
	fo.write(str(sum1))
	fo.close()
if __name__=='__main__':
       main(sys.argv[1:])




	
