#!/usr/bin/python
class Parent:
	def myMethod(self):
		print "Calling Parent method"
class Child(Parent):
	def myMethod(self):
		print "Calling child method"
c = Child()
c.myMethod()
c = Parent()
c.myMethod()
