list1  = [1,2,3]
list2 = list1.split(',')
print list2
