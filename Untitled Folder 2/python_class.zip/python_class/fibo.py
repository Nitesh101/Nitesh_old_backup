"""
a = 1
b = 1i
count = input("input number: ")

while count != 0:
	print a,

	a,b=b,a+b
	count -= 1

a = [1,2,3,4,5]
b = sum(a)
print b
"""

