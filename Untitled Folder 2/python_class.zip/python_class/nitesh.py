#!/usr/bin/python
"""
a = int(input("please enter a value %s: "))
cnt=0
for i in range(2,a):
	if(a%i==0):
		print "not a prime"
		cnt+=1		
		break		
if(cnt==0):
	print "given num is prime"


import os 

get_list = os.path(r"/home/madisnit/python_class")
a=[]
for i in get_list():
	if i.endswith(".py"):
		a.append(i)
print a


dict = {}
dict['one'] = "this in is one"
dict[2]="this is two"
a = "votary"
t = iter(a)
print next(t)



num = input("Enter a values: ")
if num >1:
	for i in range(2,num):
		if(num%i) == 0:
			print (num,"is not a prime number")
			break

letter = 0
for letter in 'Python':
# First Example
	if letter == 'h':
		continue
	print 'Current Letter :', letter
"""


var = 10
while var > 0:
	var = var-1
	if var == 5:
		continue
	print "Current variable value: ",var
print "Good bye!"

