data = "votary"
list1 = []
for val in data:
	list1 +=val
	list1.appned(val)
print list1
#print data[::-1]
