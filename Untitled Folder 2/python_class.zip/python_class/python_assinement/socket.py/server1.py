import socket
def fibanocci(n):
	if n == 1 or n == 2:
		return 1
	elif n > 2:
		return (fibanocci(n-1) + fibanocci(n-2))
val = input("please enter a number: ")
for index in range(val):
	print index
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
ip = socket.gethostname()
sock.bind((ip,5005))
sock.listen(5)
client,addr = sock.accept()
n = client.recv(1024)
sock.send(fibanocci(n))
sock.close()
