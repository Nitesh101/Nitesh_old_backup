def fun1(*tip,**dic):
	print tup
	print dic
	return


fun1(10,20,30,num=10,val=20)
fun1(10,num=10,20,val=30)
