lis1 = input("please enter a list: ")
lis2 = set(lis1)
print lis2
