import list5


num = input("please enter a number:")
list5.duplicate(num)

