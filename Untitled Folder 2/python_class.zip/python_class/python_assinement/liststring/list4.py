lis1 = [1,2,3,4,5]
lsi2 = [2,3,4,5,6,7]
print set(lis1)&set(lsi2)
