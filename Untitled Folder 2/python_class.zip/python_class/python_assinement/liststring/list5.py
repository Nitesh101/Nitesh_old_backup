def duplicate(num):
	print set(num)
	return num 
#num = input("please enter a numbers: ")
#duplicate(num)

	
