list1 = ["a","b","c"]
val = "".join(list1)
print val
