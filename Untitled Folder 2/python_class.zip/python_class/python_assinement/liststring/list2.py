tup = (1,2,3,4,5)
tup2 = (6,7,8)
print tup+tup2
"""
print "Before add a element",tup
tup1 =list(tup)
tup1[3]=9
tup2 = tuple(tup1)
print "After add a element",tup2
"""
