list1 = ["a","b","c"]
print .join(list1)
