def fun():
	global num
	global price
	global name
	num=num+10
	price=price*2
	name='Nitesh'
	print num,price,name
	return


num=100
price=500.567
name='Veera'
print num,price,name	
fun()
print num,price,name	
