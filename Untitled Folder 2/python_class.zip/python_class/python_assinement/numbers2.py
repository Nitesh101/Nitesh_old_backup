#loop control statements
"""
#3
input_string = " "
while(1):
	input  = raw_input('add to string: ')
	if input == 'quit' :
		break
	input_string += input
"""


