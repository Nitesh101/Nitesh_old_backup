#!/usr/bin/pythoni
"""
#conversions
#1
val = input("please enter a values : ")
print list(val)
print tuple(val)
val2 = input("please enter a dict values : ")
dict = {}
dict[val]=val2
print dict

#2
str = "this is python programming"
print str
str = ""this is python programmig""
print str
str = """this is pyhton programming"""

#3
x = 1
print(eval('x+1'))

#assignment
#1
val = input("please enter a values : ")
dec = val
print (bin(dec),"in binay.")
print (oct(dec),"in octal.")
print (hex(dec),"in hexadecimal")

#1
a = 10
b = 30
c = 0
c = a+b
print "line-1 value of c is",c
c = a-b
print "line-2 value of c is",c
c = a * b
print "line-3 value of c is",c

a = 1
b = 4
if (a == b):
	print "a is equal to b"
else:
	print "a is not equal to b"

"""
"""
# conditional statements

#1
val = input("please enter input: ")
val2 = input("please enter input: ")
if val > val2:
	print val
else :
	print val2

#2

val1=input("enter a number: ")
val2=input("enter a number: ")

if (val1>val2):
	if (val2>val1):
		print "greatest is", val2
		print "smallest is", val1
	if (val2<val1):
		print "greatest is", val1
		print "smallest is", val2
if (val1<val2):
	if(val2>val1):
		print "greatest is",val2
		print "smalest is",val1
	if(val2<val1):
		print "greatest is",val1
		print "smalest is",val2



elif (val2==val1):
	print "both are same"
			
val1 = input("enter a number: ")
val2 = input("enter a number: ")
condition = input("enter which operation you need: 1 - sum, 2 - subtraction, 3 =multiplication, 4 - divison: ")
if (condition == 1):
	print "The sum of the numbers",val1+val2
if(condition == 2):
	print "The subtraction of the numbers",val1-val2
if(condition == 3):
	print "The multiplication of the numbers",val1*val2
if(condition == 4):
	print "The divison of the numbers",val1/val2





#loops
#1

val = input("enter a value: ")
for val in range(3):
	print val

#2
val = input("enter a value: ")
for val in range(1,3):
	print val

#3
val = input("enter a value: ")
for val in range(1,3,1):
	print val

#4
init_val=input("please enter initial value")
final_val=input("please enter final value")
inc_val=input("please enter  inc/dec value")
for val in range(init_val,final_val,inc_val):
	print val


#5
str1=input("enter a string: ")
sub_str=input("enter the sub string: ")
if(sub_str in str1):
	print sub_str,"is a substring of",str1
elif(sub_str not in str1):
	print sub_str,"is not a substring",str1

#6
data=input("please enter a list: ")
lst=input("please enter a number which is need to search : ")
length=len(data)
for index in range(length):
	if(lst==data[index]):
		print "number is present\nindex of the number is",index
		break
else:
	print lst,"is not present in list"


#7
while(1):
	val=input("enter a number: ")
	if(val == 3):
		break
	else:
		continue


num = input("please enter a number : ")
if num >0:
	for i in  range(1,num):
		if(num%i) == 0:
			print "number is not a prime number"
		break
	else:
		print "this is prime number"


from operator import add
val = input("enter a vlues : ")
val2 = input("enter a vlaues: ")
print map(add,val,val2)

"""

a = 10
b = 20
c = a+b
print "line-1 value of c",c
c = a-b
print "line-2 value of c",c
c = a*b
print "line-3 value of c",c
c = a/b
print "line-4 value of c",c
c = a//b
print "line-4 value of c",c
c = a%b
print "line-4 value of c",c

val1 = 10
val2 = 10
val = 0
if (a==b):
	print "a value is equal to b"
else:
	print "a not equal b"


if (a!=b):
	print "a no equal to b"
else:
	print "a eual to b"


if (a<b):
	print "a is greater than b"
else:
	print "a is less than b"

if (a>=b):
	print " a is greater than or equal to b"
else:
	print " a is less than or quual to b"

	print "a no equal to b"
	print "a no equal to b"

#3

v1 = input("please enter a value: ")
v1 +=10
print v1
v1  = 10
print v1
v1 -= 10
print v1
v1 *=10
print v1
v1 /= 10
print v1
v1 **= 10
print v1



#4

val = [1,2,3,4,5]
val2 = [1,2,3,3,2]
print val is val2
print val is not val2

#5
list1 = [1,2,3,4,20]
v1 = 10
v2 = 20
res = 3 in list1
print res




list1 = [1,2,3,4,5,6]
list2 = [1,2,7,8,9,8]
mylist = []
for list1 not in list2:



v1 = 0563
v2 = 654
print v1&v2
print v1 ^ v2
print v1 | v2

str = "nitesh"
res = "n" in list
print res




list = "nitesh"
list2 ="veeranitesh"
for list not in list1:

val = input("please enter a firstdecimal value: ")
val2 = input("please enter a second value: ")
print val&val2

val = input("please enter a firstbinary value: ")

val2 = input("please enter a seconbinary value: ")
print val^val2

val = input("please enter a firsthexadecimal value: ")
val2 = input("please enter a secondhexadecimal value: ")
print val|val2



val = input("please enter a decimal number : ")
ops = input("please eneter a position: ")
set1 = val |(1<<ops)
print set1
clear = val1&(~1<<ops)
print clear
toggle = val ^(1<<ops)
print togle 
val2 = input("please enter a second value: ")
print val&val2
