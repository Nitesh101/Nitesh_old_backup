def sum( arg1, arg2 ):
# Add both the parameters and return them."
	total = arg1 + arg2
	print "Inside the function : ", total
	return total;
# Now you can call sum function
total = sum( 10, 20 );

total = sum(5,5);
print "Outside the function : ", total
total = sum(30,40);
