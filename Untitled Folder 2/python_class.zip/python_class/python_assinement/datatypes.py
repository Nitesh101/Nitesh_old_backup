"""
val1 = input("please enter complex numbers: ")

val2 = input("please enter  complex numbers: ")
val = val1 + val2
print val
val = val1 - val2
print val
val = val1*val2
print val
val = val1 % val2
print val 
val = val1 / val2
print val
val = val1 // val2
print val




var = 1
var2 = 2
val = var+var2
print val
val = var-var2
print val
val = var * var2
print val
val = var // var2
print val
del var
print val



import math



print math.modf(100.12)
print math.sqrt(14)


list1 = [1,2,3,4,5]
list2 = [3,4,5,6,7]
print cmp(list1,list2)
print len(list1)
print max(list1)
print min(list1)
val =  tuple(list1)
print val


tuple1 = (1,2,3,3,4)
tuple2 = (4,5,6,7,8)
print cmp(tuple1,tuple2)
print len(tuple1)
print max(tuple1)
print min(tuple1)
print list(tuple1)

list = ['nitesh',34,2,'veera']
list.append('madisetty')
print list
print list.count('nitesh')
list.extend('new')
print list
"""
aList = [123, 'xyz', 'zara', 'abc', 'xyz'];
print alist.index('abc')
list.insert(1,2017)
print list
print list.pop()
print list.remove(2)
print list.reverse()
print list.sort()



