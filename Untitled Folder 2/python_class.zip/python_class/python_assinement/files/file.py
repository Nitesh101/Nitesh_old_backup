#!/usr/bin/python

fo = open("text.txt","w")
fo.write("This is 1st line\n")
fo.write("This is 2nd line\n")
fo.write("This is 3rd line\n")
fo.write("This is 4th line\n")
fo.write("This is 5th line\n")
fo.write("This is 6th line\n")
fo.write("This is 7th line\n")
fo.write("This is 8th line\n")
fo.write("This is 9th line\n")
fo.write("This is 10th line\n")
fo.close()

fo = open("text.txt","a+")
fo.write("this extra line")
fo.close()

