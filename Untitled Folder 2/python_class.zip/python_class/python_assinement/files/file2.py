fo = open("text.txt","r")
contents = fo.read(10)
print contents

val = fo.seek(3);
str = fo.read()
print str
