"""
def flatten(lst):
	i = 0
	while i<len(lst):
		while True:
			try:
				lst[i:i+1]=lst[i]
			except(TypeError, IndexError):
				break
		i +=1
lst = {'a':1,'b':{'x':2,'y':3},'c':5}
flatten(lst)
print lst
"""

"""
from pprint import pprint as pp
flattenDict = {}
testData = {'a':1,'b':{'x':2,'y':3},'c':5}
print pp(dict(flattenDict(testData, lift=lambda x:(x,))))
"""










