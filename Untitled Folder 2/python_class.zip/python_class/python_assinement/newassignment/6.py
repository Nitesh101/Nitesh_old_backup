string = raw_input("please password: ")
upper = 0
lower = 0
splchar = 0
digit = 0
while True:
	upper,lower,digit,splchar=0,0,0,0
	if(6<len(string)<12):
		for val in string:
			if(val.isalpha() == True) and (val.isupper() == True):
				upper += 1
			elif(val.isalnum() == True) and (val.islower() == True):
				lower += 1
			elif(val.isdigit() == True):
				digit +=1
			elif(val=='$' or val=='#' or val=='@'):
				splchar +=1
		if(upper>=1 and lower>=1 and digit>=1 and splchar>=1):
			print "validation succeed"
			break
		else:
			print "validation Failed"
			string = raw_input("please enter a password: ")
	else:
		print "validation Failed"
		string=raw_input("enter password: ")

