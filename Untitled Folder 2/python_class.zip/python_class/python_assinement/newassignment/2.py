val = raw_input("Enter a binary values: ")
val2 = val.split(",")

for index in val2:
	temp=int(index,2) 
	print temp%5
