res = []
def flatten(list1):
	global res
	for val in list1:
		if isinstance(val,int):
			res.append(val)
		elif isinstance(val,list) or isinstance(val,tuple):
			flatten(val)
	return
list1 = input("please enter a list,tuple: ")
flatten(list1)
print res
 

