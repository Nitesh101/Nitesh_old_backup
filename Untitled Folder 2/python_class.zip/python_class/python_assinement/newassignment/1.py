val  = input("Enter a x value: ")
val2 = input("Enter a y value: ")
list1 = []
for i in range(val):
	temp = []
	for j in range(val2):
		temp.append(i*j)
	list1.append(temp)
print list1

