#!/usr/bin/python
import os
import sys

os.system(sys.argv[1])
