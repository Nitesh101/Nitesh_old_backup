string = input("please enter a sentence: ")
num_count = 0
let_count = 0
for ch in string:
	if ch.isalpha() == True:
		let_count += 1
	elif ch.isalnum() == True:
		num_count +=1
print "Numbers is",num_count
print "Letters is ",let_count
