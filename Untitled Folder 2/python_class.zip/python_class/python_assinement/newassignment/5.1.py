string = raw_input("please enter a input: ")
res = 0
while True:
	if (string[0] =='D'):
		temp=int(string[1:])
		res=res+temp
		string=raw_input("Enter Transction Details: ")
	elif(string[0]=='W'):
		temp1=int(string[1:])
		if (res>=temp1):
			res=res-temp1
		else:
			print "low balnce"
		string=raw_input("Enter transaction Details: ")
	elif(string == 'quit'):
		break
	else:
		print "please enter proper value D or W"
		string=raw_input("Enter Transactions details: ")
print "Total is",res
