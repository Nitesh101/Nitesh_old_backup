string = input("Enter a sentence: ")
upper = 0
lower = 0
for index in string:
	if index.isupper() == True:
		upper += 1
	elif index.islower() == True:
		lower += 1
print "Upper case",upper
print "Lower case",lower
