#!/usr/bin/python
lst = input("please enter a value: ")
count = 0
for val in range(1,lst+1):
	temp = bin(val)
	for ch in temp:
		if ch == '1':
			count+=1
print count
