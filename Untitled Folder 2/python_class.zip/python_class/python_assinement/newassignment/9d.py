flatten_dict = {}
def flatten_dic(d,p=""):
 	
#	global flatten_dict
	for key in d.keys():
		#new_key = parent_key+sep+k if parent_key else k
		if isinstance(d[key], dict):
			flatten_dict.update(flatten_dic(d[key], p = p+key+'.'))
		else:
			flatten_dict[p+key] = d[key]
	return flatten_dict
			
	
d = {'a':1,'b':{'x':2,'y':3},'c':4}
flatten_dic(d)
print (flatten_dict)
