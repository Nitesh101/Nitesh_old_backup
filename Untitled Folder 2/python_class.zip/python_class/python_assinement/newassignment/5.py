class BankAccount:
	def __init__(self):
		self.balance =0
	
	def deposit(self,amount):
		global balance 
	    	self.balance += amount
		print "you have credited ammount",self.balance
		return self.balance
	def withdraw(self,amount):
		global balance
	    	self.balance -= amount
		print "you have debited amount",self.balance
		return self.balance

a = BankAccount()
b = BankAccount()

a.deposit(100)
b.withdraw(50)

