string = raw_input("please enter a values: ")
new_line = string.split(',')
distance = []
up = 0
down =0
left = 0
right = 0
for val in new_line:
	if (val[0:2] == 'UP'):
		up+=int(val[2:])
	elif(val[0:4] == 'DOWN'):
		down+=int(val[4:])
	elif(val[0:4] == 'LEFT'):
		left+=int(val[4:])
	elif(val[0:5] == 'RIGHT'):
		right+=int(val[5:])

distance.append(up-down)
distance.append(right-left)
print distance
		
