lst = input("please enter a list: ")
res = []
for val in lst:
	res += val 
print ''.join(res)
