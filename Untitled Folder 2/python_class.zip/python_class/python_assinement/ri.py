class Vector():
	def __init__(self,num1,num2):
		self.num1=num1
		self.num2=num2
	def __add__(self,other):
		return(self.num1 + other.num1,self.num2+other.num2)
	def __repr__(self):
		return(self.num1,self.num2)
def main():
	Vect1 = Vector(2,3)
	Vect2 = Vector(2,5)
	print Vect1+Vect2
if __name__ == "__main__":	
	main()
