import math
val1=10.567
val2=10

print math.modf(val1)
print round(val1)
print math.sqrt(val1)
