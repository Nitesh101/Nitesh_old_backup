#!/usr/bin/python
import math
anumber = input("please enter a number: ")
try:
	print (math.sqrt(anumber))
except:
	print ("use absolute value")
print ("end of program")
