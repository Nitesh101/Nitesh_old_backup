#!/usr/bin/python
import math
anumber = (input("please enter a number: "))
try:
	print(math.sqrt(anumber))
except:
	print("bad value for instead")
print("End of program")
