#!/usr/bin/python
num = input("please enter a number: ")
#fact = 1
try:
	fact = 1
	if num == 0:
		fact = 1
	else:
		for val in range(1,num+1):
			fact*=val
	print fact
except:
	print("don't enter negetive value:")
print("end of program")
