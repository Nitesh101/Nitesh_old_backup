"""
string = input("please enter a string: ")
print string[::-1]

from __future__ import print_function
strn = raw_input("please enter a binary value: ")
num = int(strn,2)
rem = 0
val = []
while num!= 0:
	rem =num%8
	num = num/8
	val.append(rem)
	#var = list.append(rem)
	for ele in val:	
		
		print(ele, end="")
print("\n")

strn =  raw_input("enter a string : ")
num = int(strn,2)
a = 1
res,val,rem = 0,0,0
octal = []
while num!=0:
	rem = num%8
	octal.append(rem)
	num/=8
octal = list(octal)
for val in octal:
	res+=val*a
	a*=10
print res



strn = raw_input("please anter a string: ")
strn1 = list(set(strn))
print ''.join(strn1)


strn = input("please enter a string: ")
strn1 = input("please enter a string: ")

print cmp(strn,strn1)

"""

srn = input("please enter a string: ")
print max(srn)
print min(srn)








