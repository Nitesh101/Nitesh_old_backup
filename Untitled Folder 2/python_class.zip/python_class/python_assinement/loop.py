#loops
"""
#1

for index in range(3):
	print index

#2
for index in range(1,3):
	print index

#3
for index in range(1,3,1):
	print index

#4
init_val=input("please enter initial value: ")
final_val=input("please enter final value: ")
inc_val=input("please enter inc/dec value: ")
for val in range(init_val,final_val,inc_val):
	print val

#5
str1=input("enter a string")
sub_str=input("enter the sub string")
if (sub_str in str1):
	print sub_str ,"is a substring of",str1
elif (sub_str not in str1):
	print sub_str,"is not a substring",str1


#6
cnt=0
val = input("please enter a list : ")
val2 = input('plese enter a value or string: ')
for ele in val:
	if ele == val2:
	 	print "value found"
		cnt+=1
		break
if(cnt==0):
	print "not found"

if val2 in val:
	print True
else:
	print False

#7
while(1):
	val = input("plese enter guess number: ")
	if (val == 3):
		break
	else:
		continue

#1
val = input("please enter a value: ")
if val > 1:
	for ele in range(2,val):
		if(val%ele) == 0:
			print "user enter is not prime",val
			break
	else:
		print "user enter is prime number",val


#2
val = input("plese enter a starting value: ")
val2 = input("plese enter a ending value: ")
if val > 1:
	for num in range(val,val2):
        	for i in range(2,num):
			if(num%i) == 0:
                        	print "user enter is not prime",num
                       		break
        	else:
                	print "user enter is prime number",num



"""
#3
val  = input("please enter a value: ")
num1 = 0
cnt = 2
while (val<1):
	if val%cnt == 0:
		print "is not prime",val
		break
		cnt+=1
	num+=1
else:
	print "is prime number",val
		
	
