#s!/usr/bin/python
"""
val1 = input("enter a number: ")
val2 = input("enter a number: ")
if (val1>val2):
	if (val1>val2):
		print "greatest is",val1
		print "smalest is",val2
	if(val1<val2):
		print "greatest is",val2
		print "smaleast is",val1
if (val1<val2):
	if (val1>val2):	
		print "greatest is",val1
		print "smaleast is",val2
	if(val1<val2):
		print "greatest is",val2
		print "smaleat is",val1
elif(val1==val2):
	print "both are same"

val1 = input("enter a number: ")
val2 = input("enter a number: ")
condition = input("enter a number: 1 -sum,2 - subtraction,3 - multiplication,4 - divison : ")
if (condition == 1):
	print "sum of the numbers",val1+val2
if(condition == 2):
	print "subtraction of the numbers",val1-val2
if(condition == 3):
	print "multiplication of the numbers",val1*val2
if(condition == 4):
	print "divison of the numbers",val1/val2



init_val = input("please enter a initial value: ")
final_val= input("please enter a final value: ")
inc_val = input("please enter a inc/dec value: ")
for val in range(init_val,final_val,inc_val):
	print val




str1 = input("enter a string: ")
sub_str = input("enter a sub string: ")
if(sub_str in str1):
	print sub_str,"is substring of",str1
elif(sub_str not in str1):
	print sub_str,"is not a substring",str1

data = input("please enter a list: ")
seek = input("please entre a number which is need to search: ")
length=len(data)
for index in range(length):
	if (seek==data[index]):
		print "number is present\nindex of the number is ",index
		break;
else:
	print seek,"is not present in the list"


 

val = input("please enter a number to check prime or not")
for count in range(2,val):
	qout=val%count
	if(qout==0):
		print "entered number is not a prime number"
		break
if(qout!=0):
	print val,"is a prime number" 



import sys,getopt
def main(argv):
	sum1=0
	inpufile=""
	outputfile=""
	try:	
		opts,args=getopt.getopt(argv,"hi:o",["ifile=","ofile="])
	except getopt.GetoptError:
		print "getopts.task.py -i<inputfile> -o<outputfile>"
		sys.exit(2)
	for opt,arg in opts:
		if opt == "-h":
			print "task.py -i<inputfle> -o<outputfile>"
			sys.exit()
		elif opt in ("-i","__ifile"):
			inputfile=arg
		elif opt in ("-o","__ofile"):
			outputfile=arg
	print "input file is",inputfile
	print "output file is",outputfile
	fo = open(inputfile,"w")
	fo.write("2\n")
	fo.write("2\n")
	fo.close()
	fo = open(inputfile,"r")
	line = fo.readlines()
	for line in lines:
		sum1=str(line)
	fo.close()
	fo = open(outputfile,"w")
	fo.write(str(line))
	fo.close()
if __name__ == '__main__':
	main(sys.argv[1:])




import socktet
sock = socktet.socket(socket.AF_INET,socket.sock_STREAM)
host = socket.gethostname()
port = 1,2,3,4,5
sock.bind((host,port))
sock.listen(5)
while True:
	client_addr = sock.accept()
	mystr = client.recv(100)
	receiver = mystring*2
	client.send(res)

import socket
sock=socket.socket(socket.AF_INET,socket.sock_STREAM)
host = socktet.gethostname()
port = 1,2,3,4
sock.bind(host,port)
sock.listen(5)
while True:
	client_addr=sock.accept()
	mystr = client.recv(100)
	receiver = mystring*2
	client.send(res)

input_string = " "
while(1):
	input = raw_input("add to string: ")
	if input == "quit":
		break
	input_string += input

"""

class Vector():
	def __init__(self,num1,num2):
		self.num1=num1
		self.num2=num2
	def __add__(self,other):
		return(self.num1 + other.num1 ,self.num2+other.num2)
	def __sub__(self,other):
		return(self.num1 - other.num1, self.num2 - other.num2)
	def __mul__(self,other):
		return(self.num1 * other.num1, self.num2 * other.num2)
	def __repr__(self):
		return(self.num1,self.num2)
	def __del__(self):
		print "destroye"
		return
def main():
		Vect1=Vector(2,3)
		Vect2=Vector(4,6)
		print Vect1+Vect2
if __name__ == "__main__":
	main()













































































