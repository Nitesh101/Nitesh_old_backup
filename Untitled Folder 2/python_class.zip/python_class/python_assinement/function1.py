def fun(num,price,name):
	num=num+10
	price=price*2
	name='Nitesh'
	print num,price,name
	return


num=100
price=500.567
name='Veera'
fun(num,price,name)
print num,price,name	
