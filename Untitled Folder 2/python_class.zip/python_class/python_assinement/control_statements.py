#!/usr/bin/python
#class qustions
"""
#1
val1 = input("enter a number")
val2=input("enter a number")
if (val1>val2):
        print "The gratest value is: ",val1

if (val2>val1):
        print "The greastest value is:",val2

#2
#!/usr/bin/python
val1 = input("enter a number: ")
val2=input("enter a number: ")
if (val1>val2):
        print "The gratest value is: ",val1
	print "The smallest value is:",val2

elif (val2>val1):
        print "The greastest value is:",val2
	print "The smallest  value is:",val1

#3
val1=input("enter a number")
val2=input("enter a number")
if (val1>val2):
	print "greatest is", val1
	print "smallest is", val2
elif (val2>val1):
	print "greatest is", val2
	print "smallest is", val1

elif (val2==val1):
	print "both are same"

#4
val1=input("enter a number")
val2=input("enter a number")
val3=input("enter a number")
if (val1>val2):
	if (val3>val1):
		print "greatest is", val3
		print "smallest is", val2
	if (val3<val1):
		print "greatest is", val1
		print "smallest is", val2
	if (val3==val1):
		print "greatest is", val1
		print "smallest is", val2

if (val2>val1):
	if (val3>val2):
		print "greatest is", val3
		print "smallest is", val1
	if (val3<val2):
		print "greatest is", val2
		print "smallest is", val1
	if (val3==val2):
		print "greatest is", val2
		print "smallest is", val1


elif (val2==val1):
	print "both are same"
	if (val3>val1):
		print "greatest is", val3
		print "smallest is", val2
	if (val3<val1):
		print "greatest is", val1
		print "smallest is", val3
"""
#assignment qusetion
#1
val =  input("please enter a value: ")
val2 = input("please enter a value: ")
condition = input("enter a number: 1-sum, 2- substraction, 3-multiplication, 4-divition")
if(condition == 1):
	print "The sum of two numbers is:",val+val2
if(condition == 2):
	print "The substraction of two numbers:",val-val2
if(condition == 3):
	print "The mul of two numbers :",val*val2
if(condition == 4):
	print "The divistion of two numbers: ",val%val2                                                                                                                                                                                                                                                        
