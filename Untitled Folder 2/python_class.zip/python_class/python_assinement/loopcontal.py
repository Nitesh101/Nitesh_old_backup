#!/usr/biin/python
#1
val  = input("please enter  a list: ")
element = input("enter break value: ")
for num in val:
        if element == num:
                break
        else:
                print num

val  = input("please enter  a list: ")
element = input("enter break value: ")
for num in val:
        if element == num:
                continue
        else:
                print num
"""
cnt = 0
val = input("please enter a string: ")
while(val != "quit"):
        cnt+=1
        val = input("please enter a string: ")
print "string length is",cnt

