:#!/usr/bin/python

fo = open("nitesh.txt","r")

f = open("ramesh.txt","w")
contents = fo.read()
f.write(contents)
f.close()
fo.close()
