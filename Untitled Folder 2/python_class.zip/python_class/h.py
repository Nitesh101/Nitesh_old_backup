"""
res = []
#dic = {}
d  = [{'name':'sunny','age':25},{'name':'venu','age':23},{'name':'nitesh','age':28},{'name':'pavan','age':31}]
for val in range(d-1):
	      small  =  val['age'] 
	for val2 in range(val+1,d):
		if res[val2] < res[small]:
			small = val2['age'] 
		if val != small:
			res[val],res[small]=res[small],res[val]
print res
"""
res = {}	
list1 = []
d  = [{'name':'sunny','age':25},{'name':'venu','age':23},{'name':'nitesh','age':28},{'name':'pavan','age':31}]
for val in d:
	res = val
	for key in res.keys():
		if key == 'age':
			list1.append('age:')
			list1.append(res[key])
list2 = sorted(list1)
print list2

		


