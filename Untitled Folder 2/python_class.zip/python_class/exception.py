#!/usr/bin/python
import math
anumber = int(input("please enter an integer")
if anumber <:
	 raise Runtime Error("you con't use a nagetive number")
else:
	print(math.sqrt(anumber))
print("End of program")

