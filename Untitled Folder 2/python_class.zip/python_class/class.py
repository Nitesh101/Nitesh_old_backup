#!/iusr/bin/python

"""
class Employee:
	'comman class for all employee'
	empcount = 0
	def __init__(self,name,salary):
		self.name=name
		self.salary=salary
		Employee.empcount +=1
	def displaycount(self):
		print "Total Employee %d" % Employee.empcount
	def displayEmployee(self):
		print "Name :",self.name,"salary:",self.salary

emp1 = Employee("zara",2000)
emp2 = Employee("manni",3000)
emp1.displayEmployee()
emp2.displayEmployee()
print "Total Employee %d" %Employee.empcount

class Point:
	def __init( self, x=0, y=0):
		self.x = x
		self.y = y
	def __del__(self):
		class_name = self.__class__.__name__
		print class_name, "destroyed"
pt1 = Point()
pt2 = pt1
pt3 = pt1
print id(pt1), id(pt2), id(pt3) # prints the ids of the obejcts
del pt1
del pt2
del p

class Vector:
	def __init__(self, a, b):
		self.a = a
		self.b = b
	def __str__(self):
		return 'Vector (%d, %d)' %(self.a, self.b)

	def __add__(self,other):
		return Vector(self.a + other.a,self.b + other.b)
v1 = Vector(2,10)
v2 = Vector(1,5)
print v1+v2

"""





































