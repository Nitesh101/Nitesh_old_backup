#!/usr/bin/python
list1 = [1,3,5,8,10]
def bineary_search(list1,seek):
	low = 0
	high=len(list1)-1
	while(low<=high):
		mid=low+(high-low+1)//2
		if(list1[mid]==seek):
			return mid
		elif(list1[mid]>seek):
			high=mid+1
		else:
			low=mid+1
	return none

