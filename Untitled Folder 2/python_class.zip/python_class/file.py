#!/usr/bin/python
def add(a,b):
	result = a+b
	return result
def sub(a,b):	
	result = a-b
	return result
