str = "nitesh"
print len(str)
