cnt  = 0
val = input("please enter a string: ")
while(
