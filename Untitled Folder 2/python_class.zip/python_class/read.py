#!/usr/bin/python
infile = open('sample.txt', 'r')
contents = infile.read()
print(contents)
