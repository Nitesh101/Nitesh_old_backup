#!/usr/bin/python
input = open("sample2.txt","w")
input.write("some of code ")
input.close()
