#!/usr/bin/python
"""
import os
import time
print "Before fork"
os.fork()
print "Aftet fork1"
time.sleep(5)
os.fork()
print "After fork2"
"""
"""
import os 
import time
val  = 0
print "Before fork"
os.fork()
os.fork()
os.fork()
os.fork()
print "After fork"
val +=1
print "val is",val
"""
import os 
import time
import sys
def print_time(processName,delay):
	count = 0 
	while count < 5:	
		time.sleep(delay)
		count +=1
		print "%s: %s"%(processName,time.ctime(time.time()))
processid = os.fork()
if processid:
	print_time("Parent process: ",2)
	print processid
else:
	print_time("Child process: ",2)
	print processid
	sys.exit(0)
time.sleep(10)



















