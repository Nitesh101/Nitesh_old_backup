val =int(input("enter a input: "))
def fib(n):
	"""recursive function"""
	if n<=1:
		return n
	else:
		return(fib(n-1) + fib(n-2))
nterms = 10
if nterms <= 0:
	print ("please enter positive integer: ")
else:
	print("fibanocii sequence : ")
	for i in range(nterms):
		print (fib(i))



