#!/usr/bin/python
"""
import re
line = "Cats are smarter than dogs"
matchObj = re.match(r'dogs',line,re.M|re.I)
if matchObj:
	print "match -->matchObj.group():",matchObj.group()
else:
	print "No match!"

matchObj = re.search(r'Dogs',line,re.M|re.I)
if matchObj:
	print"mathc --->mathcObj.group():",matchObj.group()
else:
	print "No match"


import re
match = re.findall(r'dog','dog cat dog')
print match

import re
contactinfo = 'Doe,john: 555-1212'
match = re.match(r'(\w+),(\w+):,(\s+)',contactinfo)

print match.group(1)

match = re.search(r'(?p<last>\w+),(?p<first>\w+),(?p<phone\w+)',contactinfo)
print match

"""
"""
import re 
phone = "2014-959-559#This is phone Number"
num = re.sub(r'#.*$',"",phone)
print "phone Num:",num
"""

import re
x = ['9932735225','9888276390','972727256','702726368','80237733','6788967']

for i in x:
	if re.match(r'[9,7,8]{1}[0-9]{9}',i and len(i) == 10):
		print i
	else:
		print 'no'


























