#!/usr/bin/python
fo = open("new.txt","w")
fo.write("This is file1 text file1")
fo.write("this is file2 text file2")
fo.close()
