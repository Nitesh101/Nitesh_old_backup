#!/usr/bin/python
fo = open("foo.txt","w")
fo.write("python is a greate language")
fo.close()
