#!/usr/bin/python
f = open("file2.txt","w")
f.write("This is another line")
f.write("This new one line")
f.close()
