#!/usr/bin/python
import sys, getopt
def main(argv):
	inputfile=" "
	outputfile=" "
	try:
		opts,args = getopt(args, : " hi 0",["ifile=","ofile="])

