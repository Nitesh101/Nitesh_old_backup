#include<stdio.h>
int main(void)
{
	char a='x',*p1=&a;
	int b=12,*p2=&b;
	float c=12.4,*p3=&c;
	double d=16.45,*p4=&d;
	printf("size of (p1)=%u, sizeof(*p1)=%u\n",sizeof(p1),sizeof(*p1));
	printf("size of (p2)=%u, sizeof(*p2)=%u\n",sizeof(p2),sizeof(*p2));
	printf("size of (p3)=%u, sizeof(*p3)=%u\n",sizeof(p3),sizeof(*p3));
	printf(
	return 0;
}
