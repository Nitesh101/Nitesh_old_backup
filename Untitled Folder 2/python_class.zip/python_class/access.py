#!/usr/bin/python
import networking
num = input("enter a number to find fibanocci number: ")
networking.recr_fibo(num)
num1 = input("enter a number number which you need prime no or not: ")
networking.prime_number(num1)
