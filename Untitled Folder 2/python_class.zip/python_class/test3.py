#!/usr/bin/python
def len_list(input_list):
	counter = 0
	for i in input_list:
		counter=counter+1
	return counter
print len_list([1,2,3,4])
