#!/usr/bin/python
fo = open("input.txt","r")
f = open("output.txt","w")
contents = fo.read()
f.write(contents)
f.close()
fo.close()
