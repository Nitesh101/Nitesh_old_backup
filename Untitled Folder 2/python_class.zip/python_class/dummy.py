#!/urs/bin/python
a = [1,3,5,6,8,10]
high = len(a)
print high

