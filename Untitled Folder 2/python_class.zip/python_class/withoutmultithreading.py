#!/usr/bin/python
"""
import time
def delay_loop(taskName,secs):
	print "Delay loops start"
	print "%s sleep %d seconds"%(taskName,secs)
	for counter in range(secs):
		time.sleep(counter)
	print "Delay loop ends"
	return
def print_time(taskName,delay):
	count = 0
	while count<5:
		time.sleep(delay)
		count +=1
		secs=time.time()
		cal_time = time.ctime(secs)
		print "%s: %s"%(taskName,cal_time)
	return
delay_loop("Task1",4)
print_time("Task2",2)
"""
"""

import thread,time
def delay_loop(taskName,secs):
        print "Delay loops start"
        print "%s sleep %d seconds"%(taskName,secs)
        for counter in range(secs):
                time.sleep(counter)
        print "Delay loop ends"
        return
def print_time(taskName,delay):
        count = 0
        while count<5:
                time.sleep(delay)
                count +=1
                secs=time.time()
                cal_time = time.ctime(secs)
                print "%s: %s",(taskName,cal_time)
        return

try:
       thread.start_new_thread(delay_loop,("Thread-1",4,))
       thread.start_new_thread(print_time,("Thread-2",4,))
except:
	print "Error unable to start thread"
while True:
	pass
           
"""
"""
import thread,time
def print_time(taskName,delay):
        count = 0
        while count<5:
                time.sleep(delay)
                count +=1
                secs=time.time()
                cal_time = time.ctime(secs)
                print "%s: %s"%(taskName,time.ctime(time.time()))
	return

try:
	thread.start_new_thread(print_time,("Thread-1",2))
	thread.start_new_thread(print_time,("Thread-2",4))
except:
	print "uable to start thread"
while 1:
	pass


"""
"""

import threading,time

class myThread(threading,Thread):
	def __init__(self,threadid,name,counter):
		threading.Thread__init__(self)
		self.threadid = threadid
		self.name = name
		self.counter = counter
		return
	def run(self):
		print "Starting" + self.name
		print_time(self.name,self.counter,5)
		print "Exiting"+self.name
          	return
def print_time(threadName,delay,count):
	while count:
		count -=1
		time.sleep(delay)
		print (threadName,time.ctime(time.time())
        return		
       
thread1 = myThread(1,"Thread-1",1)
thread2 = myThread(2,"Thread-2",2)
thread1.start()
thread2.start()
print "Existing main thread"


"""


"""

import threading,time

class mythread(threading,Thread):
        def __init__(self,threadid,name,counter):
                threading.Thread__init__(self)
                self.threadid = threadid
                self.name = name
                self.counter = counter
                return
	def rub(self):
		threadLock.acquire()
		print "starting" + self.name
                print_time(self.name,slef.counter,5)
                threadLock.realese()
		return
def print_time(threadName,delay,count):
        while count:
                count -=1
                time.sleep(delay)
                print(threadName,time.ctime(time.time()))
        return       
threadLock=threading.Lock()
threads = []
thread1 = myThread(1,"Thread-1",1)
thread2 = myThread(2,"Thread-2",2)
thread1.start()
thread2.start()
threads.appned(thread1)
threads.append(thread2)
for t in threads:
	t.join()
print "Existing Main Thread"

"""

import threading,sys
class global_values(threading.Thread):
	globval = 0
	def __init__(self,threadID,name, loopcount):
		threading.Thread.__init__(self)
		self.threadID =threadID
		self.loopcounter = loopcount
		return
	def run(self):
		threadLock.acquire()
		print "Starting" + self.name
		for counter in range(self.loopcounter):

			global_values.globval +=1
		print "Existing" + self.name
		threadLock.release()
          	return
@classmethod
def loop_count(self):
	print "Global values is",self.globval
cmdlineargslen = len(sys.argv)
if (cmdlineargslen == 2):
	loops = int(sys.argv[1])
else:	
	loops = 10000
threadLock=threading.Lock()
threads=[]
print "Total loops",loops
thread1 = global_values(1,"Thread-1",loops)
thread2 = global_values(2,"Thread-2",loops)
thread1.start()
thread2.start()
thread1.join()
thread2.join()
print "Global values is",global_values.globval



























