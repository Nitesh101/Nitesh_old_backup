#!/usr/bin/python
fo = open("fileseek.txt","w")
fo.write("python is greate language : \nyeah its greate!!\n");
fo.close()
fo = open("fileseek.txt","r+")
str = fo.read(10);
print "read string is: ", str
position = fo.tell();
print "surrent file position"
position = fo.seek(2, 0);
str = fo.read(10);
print "Again read string is : ", str
position = fo.seek(-10, 2);
str = fo.read(10);
print "Again read string is: ", str
fo.close()
