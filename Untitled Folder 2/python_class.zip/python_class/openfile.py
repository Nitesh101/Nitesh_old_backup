#!/usr/bin/python
fo = open("foo.txt",'w')
fo.write("This is my first line %s",/n)
fo.write("This is my second line %s/n")
fo.write("This is my third line %s/n")
fo.close()
