#!/usr/bin/python
output = open("sample.txt","w")
output.write("A revised file output file \n")
output.write("write some more \n")
output.close()
output = open("sample.txt","a")
output.write("A revised output file with append option \n")
output.write("write somethong \n")
output.close()
