#!/usr/bin/python

import socket
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
host =socket.gethostname()
port = 12345
sock.bind((host,port))
sock.listen(5)
#while True:
client,addr = sock.accept()	
print "conected succfully"
mystr = client.recv(100)
receiver=mystr*2
client.send(receiver)

