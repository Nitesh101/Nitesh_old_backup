number = 2
count = input("please enter a number: ")
result = 1
while number:
	result = reduce(lambda x,y:x*y,(1,number+1))
	if str(result)[-count:] == '0'*count:
		print number
		print result
	number +=1
	result = 1
