#!/usr/bin/python
"""
val1=input("enter a number: ")
val2=input("enter a number: ")
condition=input("enter a number:1 - sum,2 - substraction,3 - multiplication,4 - division: ")
if(condition == 1):
	print "sum of the numbers",val1+val2
if(condition == 2):
	print "subsraction of the numbers",val1-val2
if(condition == 3):
	print "multiplication of the numbers",val1*val2
if(condition == 4):
	print "divistion of the numbers",val1%val2

val1=input("enter a number")
val2=input("enter a number")
val3=input("enter a number")
if (val1>val2):
	if (val3>val1):
		print "greatest is", val3
		print "smallest is", val2
	if (val3<val1):
		print "greatest is", val1
		print "smallest is", val2
	if (val3==val1):
		print "greatest is", val1
		print "smallest is", val2

if (val2>val1):
	if (val3>val2):
		print "greatest is", val3
		print "smallest is", val1
	if (val3<val2):
		print "greatest is", val2
		print "smallest is", val1
	if (val3==val2):
		print "greatest is", val2
		print "smallest is", val1


elif (val2==val1):
	print "both are same"
	if (val3>val1):
		print "greatest is", val3
		print "smallest is", val2
	if (val3<val1):
		print "greatest is", val1
		print "smallest is", val3
"""
val1=input("enter a number")
val2=input("enter a number")
if (val1>val2):
	print val1
if (val2>val1):
	print val2
if (val2==val1):
	print val2
