#!/usr/bin/python
"""
tup = (1,2,3,4)
val1,val2,val3,val4=tup
print val1
list1 = [3,4,6]
for index,item in enumerate(list1):
	print index,item
"""
#val = input("please enter a value: ")
result = [val1 for val1 in range(2,3) for val2 in range(5,8) if val2%2==0]
print result
