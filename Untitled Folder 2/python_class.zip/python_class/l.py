def fun(list1):
	res = 0
	for val in list1:
		res=res+val
	print res
	return
list1=[1,2,3,4,5]
list2=[3,4,5]
list2.append(list1)
fun(list1)
print list2
