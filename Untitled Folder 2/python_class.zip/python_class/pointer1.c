#include<stdio.h>
int main(viod)
{
	int a = 87;
	float b = 4.5;
	int *p1=&a;
	float *p2=&b;
	printf ("value of p1 = Address of a = %p\n",p1);
	printf ("value of p2 = Address of b = %p\n",p2);
	printf("Address of p1 = %p\n",&p1);
	printf("Address of p2 = %p\n",&p2);
	return 0;


}
