
a = [(1,2),(3,4),(5,6)]
res1=[]
for val in a:
	res=[]
	for index` in range(len(val)-1,-1,-1):
		res.append(val[index])
	tup=tuple(res)
	res1.append(tup)
print res1
		
"""

b =  ["ni123tesh","pav456an","sandeep","ve456nu","kir123an","bharath","nar123esh","santhosh"]
exp:
["ni123","456an","sandeep","456nu","kir123","bharath","nar123","santhosh"]		
"""
