import socktet
server_sock=socket.socket(socket.Af_INET,socket.SOCK_STREAM)
ip=sokcet.gethostname()
server_sock.bind((ip,5001))
server_sock.listen(5)
client,addr=server_sock.accept()
data = client.recv(1024)
print "data from client is",data
list1=[]
list2=[]
for index in data:
	list1+=index
str1=""
str1=data[::-1]
print str1
client.send(str1)
server_sock.close()
