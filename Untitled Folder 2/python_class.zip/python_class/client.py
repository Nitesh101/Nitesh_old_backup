#!/usr/bin/python
import socket
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#ipaddr = '192.168.1.111'
host = socket.gethostname()
port = 12345
sock.connect((host,port))
print "connected:"
mystr=sock.send("HELLO")
mystr=sock.recv(1000)
print mystr

