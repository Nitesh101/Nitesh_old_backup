#!/usr/bin/python
class Robot:
 	"""Represents a robot with a name"""
	population = 0
	def __init__(self,name):
		"""initializes the data"""
		self.name = name
		print "(intilizing{})", self.name
		Robot.population += 1
	def die(self):
		"""i am diving"""
		print "{} is being destroyed!",(self.name)
		Robot.population -= 1
		if Robot.population == 0:
			print "{} was the last one",(self.name)
		else:
			print "there are still{:d} robots.working"
	def say_hi(self):
		"""Greeting by the robot"""
		print "Greeting , my masters call me{}",(self.name)
	@classmethod
	def how_many(cls):
		"""print this is currect"""
		print "We have{:d} robot ",(cls.population)
droid1 = Robot("R2-D2")
droid1.say_hi()
