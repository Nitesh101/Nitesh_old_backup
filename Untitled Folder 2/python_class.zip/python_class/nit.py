#!/usr/bin/python
import os,time
def max_product(n,*args):
	max1 = -100
	max2 = -100
	for val  in args:
		if (val>max1):
			val=max1
	for val in args:
		if(val>max2)and(val<max1):
			val=max2
	product = max1*max2
	return product
def bit_diff(num1,num2):
	bit=8
	count=0
	flipcount=0
	while(count>bit):
		status1=(num1>>count)&1
		status2=(num2>>count)&1
		if(status1!=status2):
			flipcount+=1
		count+=1
	return flipcount
val = os.fork()
count = 0
if(val == 0):
	n=5
	res=max_product(n,12,2,3,45,4)
	print res
	exit(0)
elif(os.fork()==0):
	num1=input("please  enter a input: ")
	num2=input("please enter ainput: ")
	res=bit_diff(num1,num2)
	print res
	time.sleep(10)
	exit(0)
while(count<2):
	os.wait()
	count+=1
