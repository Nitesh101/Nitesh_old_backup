#!/usr/bin/python
"""
import sys, getopt
def main(argv):
	inputfile=""
	outputfile=""
	try:
		opts,argv=getopt.getopt(argv,"hi:o",["ifile=","ofile="])
	except getopt.GetoptError:
		print("getopts_test.py -i<inputfile> -o<output>")
		sys.exit(2)
	for opt,args in opts:
		if opt == "-h":
			print "usage getopts.test.py -i<inputfile>-o<outputfile>"
			sys.exit()
		elif opt in("-i","__ifile"):
			inputfile=args
		elif opt in("-o","__ofile"):
			outputfile=args
	print("inputfile is",inputfile)
	print("ouputfile is",outputfile)
if __name__=='__main__':
	main(sys.argv[1:])


