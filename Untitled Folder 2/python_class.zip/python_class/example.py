#!/usr/bin/python
"""
a = [1,2,3,4,5]

def find_index(number):
	num=(a.index(i) for i in a if i==number)
	return num
	c=0
	for i in a:
		if i == number:
			print "This values belons to %s",(number,c)
			print a.index(i)
			return c
		c = c+1
print find_index(4)


#print a.index(i)

mylist =range(10)
myset=[val**2 for val in mylist]
print myset
even_mul = [val for val in myset if val%2==0]
print even_mul

res = []
for val1 in range(2,4):
	for val2 in range(6,8):
		res.append(val1)
print res
"""
item = [1,2,3,4]
list(map((lambda x:x**2),item))
print list













