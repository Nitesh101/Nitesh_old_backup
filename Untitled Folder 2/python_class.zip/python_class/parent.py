#!/usr/bin/python
class Parent:
	parentAttr =100
	def __init__(self):
		print "Calling parent constructor"
	def ParentMethod(self):
		print "Calling parent Method"
	def setAttr(self,attr):
		Parent.ParentAttr = attr
	def getAttr(self):
		print "Parent attribute:",Parent.ParentAttr
class Child(Parent):	
	def __init__(self):
		print "Calling child constructor"
	def childMethod(self):
		print "Calling child method"
c = Child()
c.childMethod()
c.ParentMethod()
c.setAttr(200)
c.getAttr()
print isubclass(childMethod,ParentMethod)
