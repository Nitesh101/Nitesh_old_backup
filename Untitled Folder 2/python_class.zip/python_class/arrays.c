#include<stdio.h>
int main(void)
{
	int sum,i;
	int arr1[5] = {1,2,3,4,5};
	int arr2[5] = {3,4,5,6,7};
	
	for(i=0;i<5;i++)
	{
		sum+=arr1[i]+arr2[i];
	}
	printf("%d\n",sum);
	
} 

