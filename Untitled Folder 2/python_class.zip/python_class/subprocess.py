#!/usr/bin/pyithon
"""
import subprocess
proc = subprocess.Popen(['echo',"Hello world!"],stdoud=subprocess.PIPE)
stddata=proc.communicate()
print stddata
"""
