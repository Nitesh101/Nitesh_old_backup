#!/usr/bin/python
"""
while(1):
	str1=input("enter strings")
	if (str1=="quit"):
		break
	else:
		print len(str1)
#	list1.append(mylist[index])
		
print "got break"


while(1):
	str1=input("please enter  a string")
	if (str1 == "quit"):
		print "you are out of string"
		break
	else:
		print len(str1)
print "get break"	

mylist=input("enter a list: ")
val1=input("enter values to skip")
list1=[]
for index in range(len(mylist)):
	if (mylist[index]==val1):
		continue
        	list1.appned(mylist[index])
print list1

mylist=input("enter a list")
range_val=input("enter a range")
list1=[]
for index in range(len(mylist)):
	if (index==range_val):
		break
	list1.append(mylist[index])
		
print list1


val=input("please enter the first number")
count=0
i=0
while(count!=val-1):
		if (count<=2):

	        	qout=count%val
		if(qout==0):
			print "not prim"
			break
		else:
			i+=1
		count+=1

print val,"is a number"


val = input("please eneter number")
count = 0
i=0
while(count!=val-1):
		if(count<=2):
			


while(1):
	val=input("enter a number")
	if (val==3):
		break
	else:
		continue


num = 407
if num > 1:
	for i in range(2,num):
		if (num % i) == 0:
			print (num,"num is not prime number")
			print(i,"times",num//i,"is",num)
			break
		else:
			print(num,"is a prime number")
else:
	print(num,"is not prime number")




num = input("enter a number")
if num >1:
	for i in range(2,num):	
		if (num % i) == 0:
			print(num,"is not prime")
			break
	else:
		print(num,"is prim")



import random
count = random.randrange(10,20)
mylist=[]
for index in range(count):
	num = random.randrange(-10,20)
	mylist.append(num)
print "list is: ",mylist
mylist = filter(lambda val: val>0,mylist)
print "list with all pasitive numbers",mylist
mylist = map(lambda. val:val*val,mylist)
print "list with squared numbers",mylist
mylist = reduce(lambda val,val1:val+val1,mylist)
print "sum of all square numbers in list",mylist 


a = [1,2,3,4,5]
for index in range(len(a)):
	print a[index]


c = (6,7,8,9,10)
d = iter(c)
for index in d:
	print index

a = "votary"
for index in range(len(a)):
	print a[index]


a = "votary"
b = iter(a)
for index in b:
	print index

val =list( set('142524'))
for index in range(len(val)):
	print val[index]



val = {"name":"nitesh"}
val2 = iter(val)
for index in val2:
	print val[index],index
"""
str = "this is string example....wow!!!";
str = str.encode('base64','strict');
print "Encoded String: " + str;
print "Decoded String: " + str.decode('base64','strict')
