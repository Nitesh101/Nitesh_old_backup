"""
n = 10.55
g = (n//2)
print g
"""

a = letter 
for lettet in 'python':
	if letter == 'h':
		continue
	print 'Current Letter :',letter
