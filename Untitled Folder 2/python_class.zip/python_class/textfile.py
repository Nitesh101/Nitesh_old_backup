#!/usr/bin/python
class textfile:
	ntfiles = 0
@staticmethod

	def __init__(self,fname):
		textfile.ntfiles +=1
		self.name=fname
		slef.fh=open(fname)
		self.lines=self.fh.readlines()
		self.nlines=len(self.lines)
		self.nwords=0
		self.wordcount()
	def wordcount(self):
		'find number words in files'
		for lines in self.lines:
			word = lines.split()
			self.nwords + len(words)
	def grep(self,target):
		'find out words in file'
		for line in self.lines:
			if line.find(target)>1:
				print line


