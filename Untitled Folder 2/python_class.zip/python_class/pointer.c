#include<stdio.h>
int main(void)
{
	int age=30;
	float salary=1400.40;
	printf("Address of age=%p\n",&age);
	printf("Address of salary=%p\n",&salary);
	return 0;
}
