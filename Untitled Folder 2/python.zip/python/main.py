#!/usr/bin/python
from stack import Stack
from queue import Queue
"""
import linearsearch
import binarysearch
import buble_sort
"""

stack.stack1.push(20)
queue.queue1.append(40)
queue.queue1.apeend(10)
"""
linearsearch.linear_search(obj,item)
binarysearch.binary_search()
buble_sort.bublesort()
"""


