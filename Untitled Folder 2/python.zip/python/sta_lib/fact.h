#include<stdio.h>
long int fact(int n);
long int fib(int n);
