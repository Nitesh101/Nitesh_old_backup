#include<stdio.h>
int main()
{
	int v1,v2,v3;
	v1 = 10;
	v2 = 20;
	v3 = 30;
	return 0;
}
