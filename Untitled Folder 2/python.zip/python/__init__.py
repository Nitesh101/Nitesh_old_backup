#!/usr/bin/python
from stack import Stack
from queue import Queue
stack = Stack()
stack.push(40)
stack.push(30)
print stack


