#include<stdio.h>
int add(int a,int b)
{
	int sum;
	sum = a + b;
	printf("%p",&sum);
	return sum;

}
	
