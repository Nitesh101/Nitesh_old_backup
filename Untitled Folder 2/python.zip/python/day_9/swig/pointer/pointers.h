int multiplay_array(int b, int n );
