void add(int *, int *, int *);
void sub(int *, int *, int *);
int divide(int , int , int *);

