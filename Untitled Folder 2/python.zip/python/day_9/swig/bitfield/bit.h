int bicount(unsigned char x);
