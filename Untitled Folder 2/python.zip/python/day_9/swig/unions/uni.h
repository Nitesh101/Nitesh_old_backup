union test(int , float, char);
