#include<stdio.h>
struct emp
{
	int empid;
	char name[20];
	char loc[10];
};
