#include <stdio.h>

struct student {
	int id;
	int marks;
};

/*int main()
{
	struct student stu;
	stu.id=1;stu.marks=100;
	printf("%d %d",stu.id,stu.marks);
	return 0;
}*/

