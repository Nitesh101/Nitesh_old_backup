
void multiply_array(int *a, int n) 
{
    int i;
    for (i = 0; i < n; i++) 
        	a[i] = a[i] * 2;
}
