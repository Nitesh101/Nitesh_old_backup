#include <stdio.h>
int mysum(int a, int b)
{
    int c = a + b;
    return c;
}

