#include <stdio.h>

void myprint(void);

void myprint()
{
    printf("hello world\n");
}
