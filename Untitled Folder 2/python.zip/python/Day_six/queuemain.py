#!/usr/bin/python
import queue
queue.queue1.append(10)
queue.queue1.append(20)
