#!/usr/bin/python
import stack
import queue
"""
import linearsearch
import binarysearch
import buble_sort
"""

stack.stack1.push(20)
stack.stack1.push(30)
#stack.stack1.pop()
#stack.stack1.pop()
queue.queue1.append(40)
queue.queue1.append(10)
"""
linearsearch.linear_search(obj,item)
binarysearch.binary_search()
buble_sort.bublesort()
"""

