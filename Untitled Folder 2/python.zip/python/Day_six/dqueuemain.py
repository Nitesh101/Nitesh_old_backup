#!/usr/bin/python
import dqueue 


dqueue.dqueue1.addrear(10)
dqueue.dqueue1.addfront(20)
dqueue.dqueue1.addfront(40)
print dqueue.dqueue1.removerear()
print dqueue.dqueue1.removefront()
