#include<stdio.h>
void prime(int n);
void fib(int n);
long int fact(int n);
