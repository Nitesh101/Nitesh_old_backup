#!/usr/bin/python
import os
ppid=os.getppid()
print("the parent class is: ",ppid)
