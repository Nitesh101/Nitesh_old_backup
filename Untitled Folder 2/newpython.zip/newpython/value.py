#!/usr/bin/python
value = 10

print "value is ",value

value = 0o10
print  "value is",value

value = 0010
print "value is ",value


value =010
print "value is ",value


value = 0x10
print "value is ",value

value = 0xAB

print "value is ",value





