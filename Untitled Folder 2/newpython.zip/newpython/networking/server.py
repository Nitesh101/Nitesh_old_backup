#!/usr/bin/python
import socket
s = socket.socket()
host = socket.gethostname()
port = 123
s.bind((host,port))
s.listen(5)
while True:
	c, addr = s.accept()
	print 'Got connection from',addr
	c.send('thankyou for connecting\n')
	str1  = "nitesh"
	print len(str1)
	c.send(str1)
	c.close()
