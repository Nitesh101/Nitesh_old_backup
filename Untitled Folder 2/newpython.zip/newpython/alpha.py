#!/usr/bin/python
def alpaha(string):
	if string.isalpha():
		return True
	else:
		return False
list1 = ['Nitehs','Veera']
print list1
