#!/usr/bin/python
value =10
print type(value),value

value = -0b101011
print type(value),value
value = 0b101011
print type(value),value


value = 0x123
print type(value),value

