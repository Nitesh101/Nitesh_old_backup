#!/usr/bin/python
"""
val  = int("10",36)
print val
val = "123A"
val = val

v1 = 3
v2 = 2 
v3 = v1//v2
print v3
rem=v1%v2
print rem
mul = v1**v2
print mul
print v1%v2
v3 = 10%3
print v3
v3 = 3%10
print v3
v3 = 10%-3







v1 = 3
v2 = 2
res = v1**v2
print res
res**=v2
print res


v1 = 10
v2 = -3
print v1%v2
res /= v1
print res



res %= v1
print res

v1 =10
v2 = 20
v3 = 15
res = (v1<v2)and(v2<v3)
print "the value is:",res
res = (v1<v2)
print res

res = (v1>v2)and(v2>v3)
print res
res = (v1<v2)or 30
print res

res = (v1>v2) and 30
print res

v1 = 0563
v2 = 654
print v1&v2
print v1 ^ v2
print v1 | v2


v1  = -51
res = ~v1
print res

"""

v1 = 0x70
v2 = 0x9B
res = v1 & v2
print res

res = v1 | v2
print res

res = vi<<2


