#!/usr/bin/python
mydict = {}
mydict = locals()
print mydict.items()

mydict = globals()
print mydict.items()

