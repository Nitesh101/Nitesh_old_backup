#!/usr/bin/python
sq_str1 = 'this is single qout('')string\n'
sq = "this is double line\n"
print sq_str1
print sq
