
"""var  = 1 
while var == 1 :
# This constructs an infinite loop
	num = raw_input("Enter a number: ")
	print "You entered: ", num
print "Good bye!"
"""
char = [23,1,2,3,2,1,5,45,5]
print list(set(char))
