#!/usr/bin/python
var1 = 'Hello World'
var2 = "Python Programming"
print "var[0]:",var1[0]
print "var2[1:5]:",var2[1:5]


var1 = "Hello World"
print "update a string",var1[:6]+'python'

print "update a string",'python'+var1[5:]

print r"hello\n"
print "hello\n"
