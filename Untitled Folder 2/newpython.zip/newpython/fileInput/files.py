#!/usr/bin/python
input[val*5 for val in range(2,10,2)]
