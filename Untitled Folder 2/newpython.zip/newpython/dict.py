#!/usr/bin/python
"""
dict = {}
dict['one'] = "this is one"
dict[2] = "this is two"
dict2 = {"name":"john","code":637,"dept":"sales"}
print dict
print dict2

dict={}
dict['name']='nitesh'
dict['code']=678
dict['dept']='sales'
print dict.keys()
print dict.values()
print dict.items()
print dict


dict = {['Name']:'Zara','Age':7};
print dict['Name'];


dict = ['Name','Zara','Age',7];
dictstr = str(dict)
print "Equavalent string: %s"%dictstr


dictstr = "Dictstr" + dictstr
print dictstr



"""

dict1  = {'Name','zara','Age',7}
dict2 = dict1.copy()
print "Value: %s"% str(dict2)





