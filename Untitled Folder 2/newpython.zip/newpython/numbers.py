#!/usr/bin/python
import math
print "com(80,100):",cmp(80,100)

print "com(180,100):",cmp(180,100)

print "com(-80,100):",cmp(-80,100)

print "com(80,-100):",cmp(80,-100)





print "min(80,100):",min(80,100)

print "max(80,100):",max(80,100)

print "min(180,100):",min(180,100)

print "max(80,100):",max(80,100)


print "math.pow(100,-2):",math.pow(100,-2)
print math.pow(-100,2)
