#!/usr/bin/python
sumnums = lambda v1,v2,v3:v1+v2+v3
res = sumnums(10,20,30)
print res




