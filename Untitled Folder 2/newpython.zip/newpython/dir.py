#!/usr/bin/python
import math
content = dir(math)
print content;
print '\n'
content = dir(list)
print content;
