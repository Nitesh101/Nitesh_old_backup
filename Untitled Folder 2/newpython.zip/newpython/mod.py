#!/usr/bin/python
from fibo import fib
fib(100)
