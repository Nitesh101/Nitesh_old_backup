#!/usr/bin/python
import phone
phone.pots()
phone.lsdn()
phone.G3()
