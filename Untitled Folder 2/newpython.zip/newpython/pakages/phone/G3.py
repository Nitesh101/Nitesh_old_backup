#!/usr/bin/python
def G3():
	print "'I' am pots phone"
	return
