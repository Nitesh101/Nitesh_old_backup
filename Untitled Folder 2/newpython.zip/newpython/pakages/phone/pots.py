#!/usr/bin/python
def pots():
	print "'I' pots phone"
	return
