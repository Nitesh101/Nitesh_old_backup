#!/usr/bin/python
import sumsquarenumbers

