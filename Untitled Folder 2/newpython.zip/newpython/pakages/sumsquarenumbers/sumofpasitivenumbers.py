#!/usr/bin/python
def sumofpositive(num):
	total = 0
	for val in num:
		total = total +val
	print "sumpositive number is:",total
print sumofpositive([1,2,3,4,5])
