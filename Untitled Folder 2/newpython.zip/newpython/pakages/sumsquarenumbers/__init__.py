#!/usr/bin/python

from pasitivenumbers import pasitivenumbers
from sumofpasitivenumbers import sumofpasitivenumbers
from squrpositive import squrpositive
