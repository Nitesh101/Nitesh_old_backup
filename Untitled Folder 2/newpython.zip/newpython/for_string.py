#!/usr/bin/python
python  = 'python'
for letter in python:
	print 'Current letter',letter

vegetables = ('tomato','potato','onion')
for vegetable in vegetables:
	print "current vegetables",vegetable
