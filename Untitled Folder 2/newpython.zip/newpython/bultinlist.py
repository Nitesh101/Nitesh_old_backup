#!/usr/bin/python

"""
list1,list2=[123,'xyz'],[456,'abc']
print cmp(list1,list2);
#print cmp(list2,list1);
#list3 = list2+[786];
#print cmp(list2,list3)
list1,list2=[123,'xyz','zara'],[456,'abc']
list3 = ['abc',[123],'xyz']
print len(list1)
print len(list2)
print len(list3)
"""
v1 = [500,'nitesh',2,1]
print max(v1)
