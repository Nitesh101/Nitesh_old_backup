a = [1,2,3,4,5]
a.insert('3','9')
print a
