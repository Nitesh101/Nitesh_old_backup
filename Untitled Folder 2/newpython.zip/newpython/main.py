#!/usr/bin/python
def main()
	"pleasd ed"
	for index in range(10):
		col = random_list()
	
