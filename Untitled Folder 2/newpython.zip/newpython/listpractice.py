#!/usr/bin/python
four_None=[1,2,3,4]*4
print four_None

four_lists = [[1] for val in xrange(4)]
print four_lists



four_lists = [for val in range(4)]

print four_lists
