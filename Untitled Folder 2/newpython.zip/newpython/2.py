#!/usr/bin/python
num = input("please enter a input: ")
cntr = 0
for val in num:
	cntr = cntr+val
print "the sum of val",cntr
