#!/usr/bin/python

import sys
print("The command line argument are: ")
for args in sys.argv:
	print args
print '\n\nThe PYTHONPATH is',sys.path,'\n'
"""
import math
print 'square root of 16 is',math.sqrt(16)
"""




