#!/usr/bin/python
"""
if True:
	prints",v1,",v2 is",v2,"and v3 is",v3
 "Trie"
else:
	print "false"

if False:
	print "Answer"
	print "False"
else:
	print "Anwser"
	print "True"


if 0:
	print "0"
else:
	print "non zero"



val = raw_input("please  enter a value: ")
print "you entered",val,"of type",type(val)

counter = 1000
print counter
miles = 1000.0
print miles
"""


v1 = v2 = v3 =1
print "v1 is",v1,",v2 is",v2,"and v3 is",v3

v1 ,v2 ,v3 =1,2,"john"
print "v1 is",v1,",v2 is",v2,"and v3 is",v3

















