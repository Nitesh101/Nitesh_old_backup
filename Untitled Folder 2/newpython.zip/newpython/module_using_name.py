#!/usr/bin/python
if __name__ == '__main__':
	print 'this program is being run by itself'
else:
	print 'i am being inported from another module'
