#!/usr/bin/python
numlist =  range(10)
print numlist

startnum = 2
stopnum = 10
stepcnt = 3
numstuple = tuple(range(stopnum))
print numstuple
