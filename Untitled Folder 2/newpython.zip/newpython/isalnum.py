#!/usr/bin/python
str = "this2009";
print str.isalnum();
str = "this is string example...wow!!!";
print str.isalnum();



str = u"this2009";
print str.isnumeric();


str = "_"
seq = ("a","b","c");
print str.join(seq);


str = u"this2009"
print str.isdecimal();



mystr = "Hello World Program in Python"
res = mystr[::2]
print res
res = mystr[1:6]
print res

res = mystr[6:]
print res
res = mystr[:6]
print res
