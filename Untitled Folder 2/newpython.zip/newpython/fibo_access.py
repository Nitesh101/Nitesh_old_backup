import fibo
print fibo.fib(1000)
print fibo.fib(2000)

fibo_vals = fibo.fib2(50)
print fibo_vals
print 'Verstion',fibo.__verstion__

