#!/usr/bin/python
"""
list = [1,2,3,4,20]
v1 = 10
v2 = 20
res = 3 in list
print res




list = [1,2,3,4,5,6]
list2 = [1,2,7,8,9,8]
mylist = []
for list not in list1:


v1 = 20
v2 = 20
res =id(v1)
print res
res = id(v2)
print res
res = v1 is v2
print res
res = v1 is not v2
print res
res = (id(v1)==id(v2))
print res
v2 +=10
res = id(v1)
print res
res = v1 is v2
print res
"""  
v1 = 20
v2 = 20
v1 +=10
res = id(v1)
res = id(v2)
res = (id(v1)==id(v2))
print res





