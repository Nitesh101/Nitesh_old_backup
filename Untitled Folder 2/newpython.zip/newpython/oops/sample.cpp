#include<iostream>
class Sampleclass{
	private:
		int v1;
	private:	
		int v2;
	protected:
		int v3;
};
int main()
{
	Samplecalss sclass;
	sclass.v2 =100;
	count << sclass.v2;
	return(0);
}

