class sample:

