"""
mylist = [5,3,-48,8,-22,1,10]
list1 = []
list2 = []
for val in mylist:
	if val > 0:
		list1.append(val)

	elif val < 0:
		list2.append(val)
new_list = list1+list2
print new_list
"""

string = "harshita"
print string[0],ord(string[0])
print string[1],ord(string[1])

print chr(65)
