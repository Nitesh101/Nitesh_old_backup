#!/usr/bin/python
val1 = input("enter a number")
val2=input("enter a number")
if (val1>val2):
	print "The gratest value is: ",val1

if (val2>val1):
	print "The greastest value is:",val2
#if (val2==val1):
#	print val2

