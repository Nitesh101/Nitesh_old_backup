#!/usr/bin/python
from itertools import permutations
from itertools import combinations
a=[1,2,3,4,5]
for b in permutations(a,2):
	print b,
print "\n"
for c in combinations(a,2):
	print c,











