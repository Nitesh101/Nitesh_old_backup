#!/usr/bin/python

val1= input("Enter 1 hexa decima value:")
val2=input("Enter 2 hexa decimal value:")

and_res=val1&val2
print and_res

or_res=val1|val2
print or_res

xor_res=val1^val2
print xor_res

lft_shft=val1<<2
print lft_shft

rt_shft=val1>>2
print rt_shft

cmpl= ~val1
print cmpl
