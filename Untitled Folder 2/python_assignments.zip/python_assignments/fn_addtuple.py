#!/usr/bin/python

def fun(tup):
	res=0
	for val in tup:
		res=res+val
	print res
	return
	

tup=(1,2,3,4,5)
fun(tup)
print tup

