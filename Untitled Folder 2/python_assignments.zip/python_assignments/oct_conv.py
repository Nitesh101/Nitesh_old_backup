#!/usr/bin/python

val1=input("Enter a octal value:")

dec=int(val1)
print dec
hexa=hex(val1)
print hexa
binary=bin(val1)
print binary
