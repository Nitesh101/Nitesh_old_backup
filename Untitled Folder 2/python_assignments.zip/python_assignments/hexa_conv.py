#!/usr/bin/python

val1=input("Enter a  hexadecimal value:")

dec=int(val1)
print dec
octal=oct(val1)
print octal
binary=bin(val1)
print binary
