#!/usr/bin/python

val1=input("Enter a binary  value:")

dec=int(val1)
print dec
hexa=hex(val1)
print hexa
octal=oct(val1)
print octal
