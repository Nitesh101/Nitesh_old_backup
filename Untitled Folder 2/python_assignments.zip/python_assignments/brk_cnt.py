#!/usr/bin/python

string=input("Enter a string:")
while 1:
	if(string!='quit'):
		print len(string)
	else:
		break
	string=input("Enter a string:")
	
	
	
