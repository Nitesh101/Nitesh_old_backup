#!/usr/bin/python

def fun(list11):
	res=0
	for val in list1:
		res=res+val
	print res
	return
	

list1=[1,2,3,4,5]
fun(list1)
print list1

