#!/usr/bin/python

def fun(num,price,name):
	num=num+10
	price=price*2
	name='Harshita'
	print num,price,name
	return


num=100
price=500.567
name='Gangisetty'
fun(num,price,name)
print num,price,name	
