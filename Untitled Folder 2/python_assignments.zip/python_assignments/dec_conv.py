#!/usr/bin/python

val1=input("Enter a decimal value:")
octal=oct(val1)
print octal
hexa=hex(val1)
print hexa
binary=bin(val1)
print binary
