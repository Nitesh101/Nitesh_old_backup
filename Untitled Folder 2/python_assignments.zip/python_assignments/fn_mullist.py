#!/usr/bin/python

def fun(list1):
	res=[]
	for val in list1:
		mul=val*2	
		res.append(mul)
	print res
	return
	

list1=[1,2,3,4,5]
fun(list1)
print list1

