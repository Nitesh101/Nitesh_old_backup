fo = open("file.txt","r")
f = fo.readlines()
#print f
val = list(f)
print val
fo.close()

