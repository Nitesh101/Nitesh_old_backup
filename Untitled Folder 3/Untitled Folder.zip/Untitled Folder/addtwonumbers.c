#include<stdio.h>
int main()
{

int a,b,sum;
printf("Enter atwo numbers...");
scanf("%d%d",&a,&b);
sum = a+b;
printf("The sum is %d",sum);
return 0;
}
