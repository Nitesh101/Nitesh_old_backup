/*
#include<stdio.h>
int main()
{
	printf("C Programming\n");
	return 0;
}
*/
#include <stdio.h>
int main()
{
    int testInteger = 5;
    printf("Number = %d\n", testInteger);
    return 0;
}
