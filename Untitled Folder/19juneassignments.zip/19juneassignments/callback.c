#include<stdio.h>
void cbfunc();
void cbfunc()
{
   int a=10;
    printf("called\n");
  
}
 
int main ()
{
   int *a;
     /* function pointer */
    void (*callback)(void);
 
    /* point to your callback function */
    callback=(void *)cbfunc;
     
   /* perform callback */
   callback();
 
   return 0;
}
