#!/usr/bin/python
import ctypes
struct=ctypes.CDLL('./libstruct.so')
struct.main()

