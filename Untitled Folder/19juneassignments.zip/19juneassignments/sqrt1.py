#!/usr/bin/python
from  ctypes import CDLL,c_double
library = 'libm.so'
libs =CDLL('libm.so')
val=c_double(16)
print val
libs.sqrt.restype=c_double
res=libs.sqrt(val)
print res

