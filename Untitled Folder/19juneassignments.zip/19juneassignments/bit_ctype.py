#!/usr/bin/python
import ctypes
bit=ctypes.CDLL('./libbit.so')
bit.main()

