#!/usr/bin/python
import ctypes
call=ctypes.CDLL('./libcall.so')
call.main()

