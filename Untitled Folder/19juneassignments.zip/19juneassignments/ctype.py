#!/usr/bin/python
import ctypes
uni=ctypes.CDLL('./libuni.so')
uni.main()

