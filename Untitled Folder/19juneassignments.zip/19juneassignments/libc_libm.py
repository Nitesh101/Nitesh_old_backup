import ctypes

library = 'libc.so.6'
libs =ctypes.CDLL(library)
value= libs.abs(-5)
print "absolute value is",value

