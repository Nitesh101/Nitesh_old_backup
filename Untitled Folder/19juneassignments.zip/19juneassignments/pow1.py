from ctypes import CDLL ,c_double

library = 'libm.so.6'
libs =CDLL(library)
base=c_double(5)
power=c_double(4)
libs.pow.restype=c_double
res=libs.pow(base,power)
print "power of the value",res
