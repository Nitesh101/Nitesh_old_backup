#include<stdio.h>

int main()
{
	int a=10, b=20, c;
	c = a+b;
	printf("Result is : %d\n",c);
	return 0;
}


